#!/usr/bin/env python3


from qiskit import *
import math





def createSuperduperCircuit(qc,qr,cr):
	# dammm, i forget my circuit
	# but i have a screenshot of it ;)
	pass





def futurCipher(flag):

	cipher = bytearray()

	for b in flag:

		qr = QuantumRegister(8)

		cr = ClassicalRegister(8)

		qc = QuantumCircuit(qr,cr)

		for i in range(8):
			if b & (1 << i ):
				qc.x(qr[i])


		newByte = createSuperduperCircuit(qc,qr,cr)

		cipher.append(newByte)

	return cipher


def main():

	with open("flag.txt","rb") as f_in:
		flag = f_in.read(4096)


	cipher = futurCipher(flag)

	with open("cipher.txt","wb") as f_out:
		f_out.write(cipher)

if __name__ == '__main__':
	main()
